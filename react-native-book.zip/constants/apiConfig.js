export const NAVER_CLIENT_ID ='y2XiyDCkBX0MPWqi0NDT';
export const NAVER_CLIENT_SECRET = '8ich5Dp1_F';
